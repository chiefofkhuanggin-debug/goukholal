KHUANGGIN VILLAGE AUTHORITY WEBSITE — UPLOAD INSTRUCTIONS

This ZIP contains:
- index.html
- drone-view.html
- khuanggin-village-drone.jpg

On your Android phone:
1. Open https://github.com/chiefofkhuanggin-debug/goukholal
2. Open the repository's main file list.
3. Tap Add file > Upload files.
4. Upload all three files from this ZIP to the repository ROOT (not inside a new folder).
5. Tap Commit changes.
6. In Settings > Pages, confirm the site is deployed from the correct branch (usually main) and folder (/(root)).
7. Wait a few minutes and test:
   Homepage: https://chiefofkhuanggin-debug.github.io/goukholal/
   Drone page: https://chiefofkhuanggin-debug.github.io/goukholal/drone-view.html

Important: Keep all three files together in the repository root. The HTML files refer to the exact image name khuanggin-village-drone.jpg.
